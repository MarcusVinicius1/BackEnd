import re, json
from tkinter import messagebox

def IS_CPF(cpf) -> bool:
    REGEX = re.compile(r'^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$')
    return bool(REGEX.match(cpf))

def IS_EMAIL(email) -> bool:
    REGEX = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return bool(re.match(REGEX, email))

def IS_SENHA(senha) -> bool:
    """
        (?=.*[A-Z]) → Pelo menos uma letra maiúscula
        (?=.*[a-z]) → Pelo menos uma letra minúscula
        (?=.*\d) → Pelo menos um número
        (?=.*[@!*&%$+\-/=_]) → Pelo menos um dos símbolos permitidos
        ^.+$ → Garante que haja pelo menos um caractere na string
    """

    REGEX = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@!*&%$+\-/=_]).+$'

    if len(senha) >= 8 and re.match(REGEX, senha):
        return True
    
    return False

def IS_IDADE(idade) -> int:
    if idade < 18:
        messagebox.showwarning('ALERTA', 'Usuario(a) não foi cadastrado(a) por ser menor de idade!')
        return
    if not isinstance(idade, int):
        messagebox.showwarning('ALERTA', f'O tipo de variavel está errada\nVocê colocou: {type(idade)}\n E é: int')
        return

    return idade

def IS_INFO_EXISTENTE(NOME, SOBRENOME, EMAIL, SENHA, CPF) -> bool:
    try:
        with open('Usuario.json', 'r', encoding='utf-8') as arquivo:
            dados = json.load(arquivo)  # Carrega a lista de usuários
    except (FileNotFoundError, json.JSONDecodeError):
        return True  # Se o arquivo não existe ou está vazio, não há dados duplicados.

    # Percorre a lista de usuários
    for usuario in dados:
        if usuario.get("Nome") == NOME:
            messagebox.showwarning('ALERTA', f'{NOME} -> Esse nome já existe!')
            return False

        if usuario.get("Sobrenome") == SOBRENOME:
            messagebox.showwarning('ALERTA', f'{SOBRENOME} -> Esse sobrenome já existe!')
            return False

        if usuario.get("Email") == EMAIL:
            messagebox.showwarning('ALERTA', f'{EMAIL} -> Esse email já existe!')
            return False

        if usuario.get("Senha") == SENHA:
            messagebox.showwarning('ALERTA', f'{SENHA} -> Essa senha já existe!')
            return False

        if usuario.get("Cpf") == CPF:
            messagebox.showwarning('ALERTA', f'{CPF} -> Esse CPF já existe!')
            return False

    return True

def IS_INFORMACOES(NOME, SOBRENOME, EMAIL, SENHA, CPF, IDADE) -> bool:
    if not IS_INFO_EXISTENTE(NOME, SOBRENOME, EMAIL, SENHA, CPF):
        return False

    if not isinstance(NOME, str) or not NOME.isalpha():
        messagebox.showerror('ERRO', 'Digite apenas letras para o nome')
        return False

    if not isinstance(SOBRENOME, str) or not SOBRENOME.isalpha():
        messagebox.showerror('ERRO', 'Digite apenas letras para o sobrenome')
        return False

    if not isinstance(CPF, str) or not IS_CPF(CPF):
        messagebox.showerror("ERRO", 'CPF inválido!')
        return False

    if not isinstance(EMAIL, str) or not IS_EMAIL(EMAIL):
        messagebox.showerror('ERRO', 'Email inválido!')
        return False

    if not isinstance(SENHA, str) or not IS_SENHA(SENHA):
        messagebox.showerror('ERRO', 'Senha inválida!\n\nRegras:\n'
                                     '🔹 (?=.*[A-Z]) → Pelo menos uma letra maiúscula\n'
                                     '🔹 (?=.*[a-z]) → Pelo menos uma letra minúscula\n'
                                     '🔹 (?=.*\d) → Pelo menos um número\n'
                                     '🔹 (?=.*[@!*&%$+\-/=_]) → Pelo menos um dos símbolos permitidos\n'
                                     '🔹 ^.+$ → Garante que haja pelo menos um caractere na string')
        return False

    if not isinstance(IDADE, int) or not IS_IDADE(IDADE):
        messagebox.showerror('ERRO', 'Idade inválida!')
        return False

    return True
import re
from tkinter import messagebox

def IS_CPF(cpf):
    REGEX = re.compile(r'^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$')
    return bool(REGEX.match(cpf))

def IS_EMAIL(email):
    REGEX = r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"
    return bool(re.match(REGEX, email))

def IS_SENHA(senha) -> bool:
    """
        Uma letra maiúscula
        Uma letra minúscula
        Um símbolo (entre @! *&%$+-/= _)
    """

    REGEX = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*[@!*&%$+\-/=_]).+$'

    if len(senha) >= 8 and re.match(REGEX, senha):
        return True
    
    return False

def IS_IDADE(idade) -> int:
    if idade < 18:
        #n use gpt nem ia
        messagebox.showwarning('ALERTA', 'Usuario(a) não foi cadastrado(a) por ser menor de idade!')
        return
    if not isinstance(idade, int):
        messagebox.showwarning('ALERTA', f'O tipo de variavel está errada\nVocê colocou: {type(idade)}\n E é: int')
        return

    return idade

def IS_INFORMACOES(EMAIL, SENHA, CPF, IDADE, LISTA) -> bool:
    if not IS_CPF(CPF) or not isinstance(CPF, str):
        messagebox.showerror("ERRO", 'CPF invalido!')
        return True
    if not IS_EMAIL(EMAIL) or not isinstance(EMAIL, str):
        messagebox.showerror('ERRO', 'Email invalido!')
        return True
    if not IS_SENHA(SENHA) or not isinstance(SENHA, str):
        messagebox.showerror('ERRO', 'Senha invalida!')
        return True
    if not IS_IDADE(IDADE) or not isinstance(IDADE, int):
        messagebox.showerror('ERRO', 'Senha invalida!')
        return True
    
    return True, LISTA
import json
from tkinter import messagebox

# Função para atualizar um usuário no JSON
def Atualizar_Usuario():
    try:
        cpf_procurado = input("Digite o CPF do usuário que deseja atualizar: ")

        # Abrir e carregar os dados existentes
        with open('Usuario.json', 'r+', encoding='utf-8') as arquivo:
            dados = json.load(arquivo) # Lê o JSON como dicionário

            # Procura o usuário pelo CPF
            for usuario in dados["usuarios"]:
                if usuario["cpf"] == cpf_procurado:
                    print("\nUsuário encontrado! Escolha o que deseja atualizar:")
                    print("1. Nome")
                    print("2. Sobrenome")
                    print("3. Email")
                    print("4. Senha")
                    escolha = input("Digite o número da opção desejada: ")

                    campos = ["Nome", "Sobrenome", "Email", "Senha", "Idade"]
                    
                    if escolha in ["1", "2", "3", "4", "5"]:
                        novo_valor = input(f"Digite o novo {campos[int(escolha)-1]}: ")
                        usuario[campos[int(escolha)-1]] = novo_valor
                    else:
                        print("Opção inválida!")
                        return

                    # Volta ao início do arquivo e sobrescreve com os novos dados
                    arquivo.seek(0)
                    json.dump(dados, arquivo, indent=4, ensure_ascii=False)
                    arquivo.truncate() # Remove possíveis sobras do arquivo
                    print("Informação atualizada com sucesso!")
                    return
    except ValueError as err:
       print('\nErro ao atualizar informação do usuario(a) ou não foi encontrado(a)!\n', err)
    
    finally:
       messagebox.showerror('OK', 'Informação de usuário(a) foi atualizado(a)!')
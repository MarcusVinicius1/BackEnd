from Create import Criar
from Delete import Deletar
from Read import Carregar
from Update import Atualizar_Usuario
import os, sys, json
from time import sleep

os.system('cls' if os.name == 'nt' else 'clear')
ListTypePassWord = [
    '(?=.*[A-Z]) → Pelo menos uma letra maiúscula',
    '(?=.*[a-z]) → Pelo menos uma letra minúscula',
    '(?=.*\d) → Pelo menos um número',
    '(?=.*[@!*&%$+\-/=_]) → Pelo menos um dos símbolos permitidos',
    '(^.+$) → Garante que haja pelo menos um caractere na string'
]

def Resource_Path(relative_path):
    """
    Retorna o caminho absoluto para o recurso.
    Funciona tanto em ambiente de desenvolvimento quanto no executável criado pelo PyInstaller.
    """
    try:
        # Se estiver rodando como executável, sys._MEIPASS será definido.
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

def Menu():
    MenuList = ['Cadastrar', 'Atualizar', 'Deletar', 'Carregar', 'Sair']
    for Index, Lista in enumerate(MenuList):
        print('{}. {}'.format(Index+1, Lista))

def main():
    Menu()
    CodigoNav = 0

    while True:
        try:
            CodigoNav = int(input('\nNav: '))

            match CodigoNav:
                case 1: 
                    NOME = input('\nNome: ').capitalize()
                    SOBRENOME = input('Sobenome: ').capitalize()
                    EMAIL = input('Email: ')
                    print('\nRegras da criação da senha\n')
                    
                    for Index, Lista in enumerate(ListTypePassWord):
                        print('{}. {}'. format(Index+1, Lista))
                        sleep(.2)

                    SENHA = input('\nSenha: ')
                    CPF = input('Cpf: ')
                    IDADE = int(input('Idade: '))

                    Criar(NOME, SOBRENOME, EMAIL, SENHA, CPF, IDADE)
                case 2: Atualizar_Usuario()
                case 3: 
                    Qual_Cpf = input('\nCPF: ')
                    Deletar(Qual_Cpf)
                case 4: Carregar()
                case 5: break
        except ValueError:
            print('\nCodigo invalido, somente numeros!')

if __name__ == '__main__':
    config_file = Resource_Path("config.json")

    with open(config_file, "r", encoding="utf-8") as f:
        config = json.load(f)
    # print("Nome do aplicativo:", config["nome"])
    # print("Versão:", config["versao"])
    main()
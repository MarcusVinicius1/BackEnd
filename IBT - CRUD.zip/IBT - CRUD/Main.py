from Create import Criar
from Delete import Deletar
from Read import Carregar
from Update import Atualizar_Usuario
import os

os.system('cls' if os.name == 'nt' else 'clear')

def Menu():
    MenuList = ['Cadastrar', 'Atualizar', 'Deletar', 'Carregar', 'Sair']
    for Index, Lista in enumerate(MenuList):
        print('{}. {}'.format(Index+1, Lista))

def main():
    CodigoNav = 0

    while True:
        try:
            Menu()
            CodigoNav = int(input('\nNav: '))

            match CodigoNav:
                case 1: 
                    NOME = input('\nNome: ')
                    SOBRENOME = input('Sobenome: ')
                    EMAIL = input('Email: ')
                    SENHA = input('Senha: ')
                    CPF = input('Cpf: ')
                    IDADE = int(input('Idade: '))

                    Criar(NOME, SOBRENOME, EMAIL, SENHA, CPF, IDADE)
                case 2: Atualizar_Usuario()
                case 3: 
                    Qual_Cpf = input('\nCPF: ')
                    Deletar(Qual_Cpf)
                case 4: Carregar()
                case 5: break
        except ValueError:
            print('\nCodigo invalido, somente numeros!')

if __name__ == '__main__':
    main()
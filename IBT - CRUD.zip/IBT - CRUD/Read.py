import json
from tkinter import messagebox

def Carregar():
    try:
        # Abrir e ler o arquivo JSON
        with open('Usuario.json', 'r', encoding='utf-8') as arquivo:
            dados = json.load(arquivo)

        # Percorrer a lista de usuários e exibir as informações
        print('\n-- Usuarios\n')
        for usuario in dados.get("usuarios", []):
            print(f"Nome: {usuario.get('nome')}")
            print(f"Sobrenome: {usuario.get('sobrenome')}")
            print(f"Email: {usuario.get('email')}")
            print(f"Senha: {usuario.get('senha')}")
            print(f"CPF: {usuario.get('cpf')}")
            print("-" * 30)
        
        print('\n')
    except ValueError as err:
        print('\nErro ao carregar os usuario(a)s!\n', err)
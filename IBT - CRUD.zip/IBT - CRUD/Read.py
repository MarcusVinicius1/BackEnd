import json
from tkinter import messagebox

def Carregar():
    try:
        # Abrir e ler o arquivo JSON
        with open('Usuario.json', 'r', encoding='utf-8') as arquivo:
            dados = json.load(arquivo)

        if not dados.get('usuarios'):
            messagebox.showwarning('ALERTA', 'Não tem nunhum usuario(a) salvo!')
            return

        # Percorrer a lista de usuários e exibir as informações
        print('\n-- Usuarios\n')
        for usuario in dados.get("usuarios", []):
            print(f"Nome: {usuario.get('Nome')}")
            print(f"Sobrenome: {usuario.get('Sobrenome')}")
            print(f"Email: {usuario.get('Email')}")
            print(f"Senha: {usuario.get('Senha')}")
            print(f"CPF: {usuario.get('Cpf')}")
            print(f'Idade: {usuario.get('Idade')}')
            print("-" * 30)
        
        print('\n')
    except ValueError as err:
        print('\nErro ao carregar os usuario(a)s!\n', err)
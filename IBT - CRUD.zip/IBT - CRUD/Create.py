from Validar import IS_INFORMACOES
import json
from tkinter import messagebox

def Criar(NOME, SOBRENOME, EMAIL, SENHA, CPF, IDADE):
    LISTA_ERROS_INFORMACAO = []
    # Validar informações
    if not IS_INFORMACOES(EMAIL, SENHA, CPF, IDADE, LISTA_ERROS_INFORMACAO):
        messagebox.showwarning('ALERTA', 'Confira as informações que está incorretos')

        for Index, Lista in enumerate(LISTA_ERROS_INFORMACAO):
            print("{}. {}".format(Index+1, Lista))

        return

    # Novo usuário a ser adicionado
    novo_usuario = {
        "Nome": f"{NOME}",
        "Sobrenome": f"{SOBRENOME}",
        "Email": f"{EMAIL}",
        "Senha": f"{SENHA}",
        "Cpf": f"{CPF}",
        "Idade": f"{IDADE}"
    }

    try:
        # Abrir e carregar os dados existentes
        with open('Usuario.json', 'r+', encoding='utf-8') as arquivo:
            dados = json.load(arquivo) # Lê o JSON como dicionário
            dados["usuarios"].append(novo_usuario) # Adiciona o novo usuário à lista

            # Volta ao início do arquivo e sobrescreve com os novos dados
            arquivo.seek(0)
            json.dump(dados, arquivo, indent=4, ensure_ascii=False)  
            arquivo.truncate() # Remove conteúdo excedente caso o novo JSON seja menor
    except ValueError as err:
        print('\nErro ao salvar o novo usuario(a)!\n', err)
    
    finally:
        messagebox.showinfo('OK', 'Usuario(a) cadastrado(a)!')
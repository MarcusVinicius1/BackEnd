import json
from tkinter import messagebox

def Deletar(CPF):
    try:
        # CPF do usuário que será removido
        cpf_para_remover = CPF

        # Abrir e carregar os dados existentes
        with open('Usuario.json', 'r+', encoding='utf-8') as arquivo:
            dados = json.load(arquivo) # Lê o JSON como dicionário

            # Filtra a lista de usuários, removendo aquele com o CPF correspondente
            dados["usuarios"] = [usuario for usuario in dados["usuarios"] if usuario["cpf"] != cpf_para_remover]

            # Volta ao início do arquivo e sobrescreve com os novos dados
            arquivo.seek(0)
            json.dump(dados, arquivo, indent=4, ensure_ascii=False)
            arquivo.truncate() # Remove possíveis sobras do arquivo
    except ValueError as err:
        print('\nErro ao deletar o usuario(a)!\n')
    
    finally:
        messagebox.showinfo('OK', 'O usuario(a) foi deletado(a)!')
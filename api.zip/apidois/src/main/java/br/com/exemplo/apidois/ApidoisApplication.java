package br.com.exemplo.apidois;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApidoisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApidoisApplication.class, args);
	}

}

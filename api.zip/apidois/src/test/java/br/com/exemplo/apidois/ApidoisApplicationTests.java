package br.com.exemplo.apidois;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApidoisApplicationTests {

	@Test
	void contextLoads() {
	}

}
